<?php

add_theme_support('menus' );
register_nav_menus(array(
	'top-menu' => __('Top Menu','theme')
	
));



/**
 * OG Custom functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package OG_Custom
 */

if ( ! function_exists( 'og_custom_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function og_custom_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on CT Custom, use a find and replace
		 * to change 'ct-custom' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'ct-custom', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'ct-custom' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'ct_custom_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'og_custom_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function og_custom_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'og_custom_content_width', 640 );
}
add_action( 'after_setup_theme', 'og_custom_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function og_custom_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'og-custom' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'og-custom' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'og_custom_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function og_custom_scripts() {
	wp_enqueue_style( 'og-custom-style', get_stylesheet_uri() );
	wp_enqueue_style('og-main', get_template_directory_uri() . '/assets/css/style.css');

	wp_enqueue_script( 'og-custom-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'og-custom-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );
	
	wp_enqueue_script( 'og-custom-script', get_template_directory_uri() . '/assets/js/custom.js', array('jquery') );
	
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'og_custom_scripts' );


/**
 * Custom Google Fonts
 */
function enqueue_custom_fonts() {
	if(!is_admin()) {
		wp_register_style('poppins', 'https://fonts.googleapis.com/css2?family=Poppins:wght@500;400;700&display=swap');


		wp_register_style('Oswald', 'https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400;500;600;700&display=swap');

		

		
		wp_enqueue_style('poppins');
		wp_enqueue_style('Oswald');
	}
}

/**
 * Fontawesome
 */

add_action('wp_enqueue_scripts', 'enqueue_custom_fonts');

add_action( 'wp_enqueue_scripts', 'add_font_awesome' );

function add_font_awesome() {
wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css

' );
}


/**
 * Custom Theme Settings for WordPress
 * 
 */

	add_action("admin_menu", "mythemesettings");

	function mythemesettings(){
		// admi panel menu code
		add_menu_page("theme-settings",
		"Theme Settings",
		"manage_options",
		"theme-settings",
		"mycustom_settings", 
		"dashicons-sticky"
	);
	}

	function mycustom_settings(){
		?>
<div>
  <h1>Theme Settings</h1>
  <form action="#" method="post">
    <?php
				settings_fields("section");
				do_settings_sections( "theme-settings" );

				submit_button();
				?>
  </form>
</div>
<?php
	}

	function theme_settings_setting(){
		add_settings_section(
			"section",
			"All page",
			null,
			"theme-settings"
		);

		add_settings_field(
			"upload_logo",
			"Upload Logo",
			"display_logo",
			"theme-settings",
			"section"
		);


		add_settings_field(
			"phone_number",
			"Phone Number",
			"display_phone_number",
			"theme-settings",
			"section"
		);


		add_settings_field(
			"address_info",
			"Address Information",
			"display_address_info",
			"theme-settings",
			"section"
		);

		register_setting("section", "upload_logo", );
		register_setting("section", "phone_number", );
		register_setting("section", "address_info" );
	}

	add_action("admin_init", "theme_settings_setting");

	function display_logo(){
		?>

<input type="file" name="upload_logo" value="" id="upload_logo" />
<?php
	}


	function display_phone_number(){
		?>

<input type="text" name="phone_number" value="" id="phone_number" />
<?php
	}


	function display_address_info(){
		?>

<textarea name="address_info" value="" rows="5" cols="35" id="address_info" /></textarea>
<?php
	}


/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require get_template_directory() . '/inc/woocommerce.php';
}