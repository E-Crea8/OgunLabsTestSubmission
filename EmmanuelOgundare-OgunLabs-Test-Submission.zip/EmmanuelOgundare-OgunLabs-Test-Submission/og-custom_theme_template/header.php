<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CT_Custom
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'ct-custom' ); ?></a>

    <header id="masthead" class="site-header">
      <!-- <div class="site-branding">
			<?php
			// the_custom_logo();
			if ( is_front_page() && is_home() ) :
				?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php
			else :
				?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
				<?php
			endif;
			$ct_custom_description = get_bloginfo( 'description', 'display' );
			if ( $ct_custom_description || is_customize_preview() ) :
				?>
				<p class="site-description"><?php echo $ct_custom_description; /* WPCS: xss ok. */ ?></p>
			<?php endif; ?>
      </div>.site-branding -->
      <div class="top-info">
        <div class="top-bar">
          <div class="top-bar__phone-box">
            <p>
              call us now!
              <span>385.154.11.26.35</span>
            </p>
          </div>

          <div class="top-bar__links">
            <a href="" class="top-bar__links--login"> login </a>
            <a href="" class="top-bar__links--signup"> signup </a>
          </div>
        </div>
      </div>

      <!-- NAVBAR Section -->
      <div class="main-nav">
        <div class="nav-box">

          <div href="/" class="nav-box__logo">
            <?php the_custom_logo(); ?>

            <!-- Before using the wordpress custom logo -->
            <!-- <span class="dark-text">YOUR</span>
            <span class="primary-text">LOGO</span> -->
          </div>

          <!-- ion-icons for mobile menu -->
          <button class="btn-mobile-nav" id="btn-mobile-nav" onclick="toggleMobileMenu(this)">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon-mobile-nav" viewBox="0 0 512 512">
              <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="32"
                d="M80 160h352M80 256h352M80 352h352" />
            </svg>


            <!-- <svg xmlns="http://www.w3.org/2000/svg" class="icon-mobile-nav" viewBox="0 0 512 512">
              <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"
                d="M368 368L144 144M368 144L144 368" />
            </svg> -->
          </button>


          <nav id="site-navigation" class="navbar">
            <!-- <button class="menu-toggle" aria-controls="primary-menu"
              aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'ct-custom' ); ?>
            </button> -->


            <!-- <div class="navbar__bars">
              <svg class="nav-icon" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd">
              <svg class="nav-icon" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 18v1h-24v-1h24zm0-6v1h-24v-1h24zm0-6v1h-24v-1h24z" />
                <path d="M24 19h-24v-1h24v1zm0-6h-24v-1h24v1zm0-6h-24v-1h24v1z" />
              </svg>
              </div> -->

            <!-- Static menu for test  -->
            <!-- <ul class="navbar__menu">
                  <li>
                    <a href="/" class="navbar__menu--links">title 1</a>
                  </li>

                  <li>
                    <label for="link-2" class="show"></label>

                    <a href="/" class="navbar__menu--links">title 2</a>

                    <input type="checkbox" id="link-2">

                    
                <ul>
                  <li>
                    <a href="#"> submenu 1 </a>
                  </li>

                  <li>
                    <a href="#"> submenu 2 </a>
                  </li>

                  <li>
                    <a href="#"> submenu 3 </a>

                    
                    <ul>
                      <li>
                        <a href="#"> submenu 1 </a>
                      </li>

                      <li>
                        <a href="#"> submenu 2 </a>
                      </li>

                      <li>
                        <a href="#"> submenu 3 </a>
                      </li>
                    </ul>


                  </li>
                </ul>

                </li>

                <li>
                  <a href="/" class="navbar__menu--links">title 3</a>
                </li>

                <li>
                  <a href="/" class="navbar__menu--links">title 4</a>
                </li>

                <li>
                  <a href="/" class="navbar__menu--links">title 5</a>
                </li>

                <li>
                  <a href="/" class="navbar__menu--links">title 6</a>
                </li>

                <li>
                  <a href="/" class="navbar__menu--links">title 7</a>
                </li>

            </ul>-->

            <?php wp_nav_menu(array(
							'menu' => 'top-menu',
							'menu_class' => 'navbar__menu',
							'container' => '',
							'li_class' => 'nav-item',
							'a_class' => 'nav-link',
							'active_class' => 'active'
					));
					?>


          </nav><!-- #site-navigation -->



        </div>
      </div>


    </header><!-- #masthead -->

    <div id="content" class="site-content">