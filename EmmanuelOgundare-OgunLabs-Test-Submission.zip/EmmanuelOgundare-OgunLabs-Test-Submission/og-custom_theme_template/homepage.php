<?php
/**
 * Template Name: Homepage
 * 
 */

 get_header(); 
 ?>


<main>
  <!-- spacing -->
  <div class="space-box-sm"></div>

  <!-- Display breadcrumbs -->
  <section class="breadcrumbs">
    <div class="container">
      <div class="inactive-link">
        <a href="#">
          Home /
        </a>
      </div>


      <div class="inactive-link">
        <a href="#">
          Who we are /
        </a>
      </div>

      <div class="active-link">
        <a href="#">
          Contact
        </a>
      </div>
    </div>
  </section>

  <!-- spacing -->
  <div class="space-box-sm"></div>

  <!-- Display ACFs for contact page -->
  <?php 
  if( have_rows('contact_page') ):
    // loop through the rows of data
    while ( have_rows('contact_page') ) : the_row(); 
?>


  <!-- Get all the fields in the Section -->
  <?php if( get_row_layout() == 'description_section' ): ?>

  <?php 
$title = get_sub_field('title'); 
$descriptionText = get_sub_field('description_text'); 
?>
  <!-- Section Contact Info-->
  <section class="contact-info">
    <div class="container">
      <div class="container__desc-text">
        <?php if( !empty($title)): ?>
        <h2>
          <?php echo $title; ?>
        </h2>
        <?php endif; ?>

        <?php if( !empty($descriptionText)): ?>
        <p>
          <!-- Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem commodi amet ullam, ducimus aspernatur
          voluptatibus hic repellendus totam autem iste molestiae accusamus inventore, illo obcaecati ratione quis
          provident consectetur. Dolor! -->
          <?php echo $descriptionText; ?>
        </p>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <?php endif; ?>

  <!-- spacing -->
  <div class="space-box-md"></div>

  <!-- Get all the fields in the Section -->
  <?php if( get_row_layout() == 'contact_us_reach_us_section' ): ?>
  <?php 
  $titleCol1 = get_sub_field('column_1_box_title'); 
  $titleCol2 = get_sub_field('column_2_title'); 
  $address = get_sub_field('address'); 
  $phone = get_sub_field('phone'); 
  $fax = get_sub_field('fax'); 
  ?>


  <!-- Contact and Reach us details -->
  <section class="contact-reach-us">
    <div class="container grid grid--2-cols">
      <div class="container__contact-form-box">
        <?php if( !empty($titleCol1)): ?>
        <h2 class="container__contact-form-box--title">
          <?php echo $titleCol1; ?>
        </h2>
        <?php endif; ?>

        <div class="contact-shortcode">
          <!-- Add contact form 7 shortcode here -->
          <?php echo do_shortcode("[contact-form-7 id='10' title='Contact form']"); ?>
        </div>
      </div>

      <div class="container__reach-us-box">
        <?php if( !empty($titleCol2)): ?>
        <h2 class="container__reach-us-box--title">
          <?php echo $titleCol2; ?>
        </h2>
        <?php endif; ?>

        <div class="info-box">
          <?php if( !empty($address)): ?>
          <p>
            <?php echo $address; ?>
          </p>
          <?php endif; ?>

        </div>

        <div class="phone-fax-box">
          <?php if( !empty($phone)): ?>
          <p>
            <?php echo $phone; ?>
          </p>
          <?php endif; ?>

          <?php if( !empty($fax)): ?>
          <p>
            <?php echo $fax; ?>
          </p>
          <?php endif; ?>
        </div>

        <div class="space-box-md"></div>

        <div class="social-box">
          <a href="https://facebook.com">
            <i class="fa fa-facebook social_icon" aria-hidden="true"></i>
          </a>

          <a href="https://twitter.com">
            <i class="fa fa-twitter social_icon" aria-hidden="true"></i>
          </a>

          <a href="https://linkedin.com">
            <i class="fa fa-linkedin social_icon" aria-hidden="true"></i>
          </a>

          <a href="https://pinterest.com">

            <i class="fa fa-pinterest social_icon" aria-hidden="true"></i>
          </a>


          <p></p>
        </div>
      </div>

    </div>
  </section>

  <?php endif; ?>

  <?php 
  endwhile;
  endif; 
?>

</main>